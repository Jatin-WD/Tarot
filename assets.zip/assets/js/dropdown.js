$('.menu-dropdown button').click(function(){
    $('.menu-list').toggleClass('active');
  });